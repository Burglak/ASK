#include <stdio.h>

int main() {
	printf("mul.c\n\n");
	
	unsigned int a = 4294967295u;
	unsigned int b = 2;
	
	unsigned int w = a*b;
	
	printf("a = %u\n", a);
	printf("b = %u\n\n", b);
	printf("iloczyn = %u", w);
	
	return 0;
}
