#include <stdio.h>

int main() {
	printf("process.c\n\n");
	
	int x;
	int y;
	
	int *p_x = &x;
	int *p_y = &y;
	
	printf("&x = %p\n", p_x); // specifier %p do wskaznikow
	printf("&y = %p\n", p_y);
	
	return 0;
/*	
	x [ ][ ][ ][ ]   &x = 0061FE94
	y [ ][ ][ ][ ]   &y = 0061FE90	
*/

}

