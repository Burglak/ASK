#include <stdio.h>

int main() {
	printf("bits.c\n\n");
	
	void *p; // wska�nik na dowolny obszar w pami�ci
	size_t bytes = sizeof(p); // size_t to unsigned long, mozna int i char i nic sie nie stanie
	
	if (bytes == 4) printf("I'm a 32-bit program.\n");
	if (bytes == 8) printf("I'm a 64-bit program.\n");
	
	return 0;
}

