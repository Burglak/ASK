#include <stdio.h>

int main() {
	printf("bytes.c\n\n");
	
	int x = 260;
	
	printf("value x = %u\n\n", x);
	
	unsigned char *p = (char*)&x;
	
	printf("address = %p\n\n", p);
	
	printf("bytes = %.3u %.3u %.3u %.3u\n", *p, *(p + 1), *(p + 2), *(p + 3));
	
	return 0;
}

